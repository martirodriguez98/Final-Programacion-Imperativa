Para compilar, ejecutar en la línea de comandos: make all

Para correr el programa, ejecutarlo en la línea de comandos seguido del archivo de provincias y el archivo de nacimientos, en ese orden. Por ejemplo: ./nacidos provincias.csv nacimientos.csv