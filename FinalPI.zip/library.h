#ifndef LIBRARY_H
#define LIBRARY_H
#include <stdio.h>
#include "dataADT.h"
#include <stdlib.h>

//funciones que realizan los queries
void query1(dataADT p);
void query2(dataADT p);
int query3(dataADT p);
#endif
